# RELATÓRIO DE IMPLEMENTAÇÃO DE SERVIÇOS AWS

Data: 05/03/2026
Empresa: Abstergo Industries
Responsável: Luis Ricardo

## Documentação

Relatório completo do projeto:

[Relatório Técnico](docs/relatorio.md)

## Serviços AWS Utilizados

![AWS Services](assets/aws-services.png)